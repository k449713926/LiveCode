<?php

if(isset($_GET['id'])){

   $id = $_GET['id'];

}else{

	die;

}





$zongduan['0']['name']='前端1';
$zongduan['0']['ip']='139.155.12.96';

if($zongduan[$id]['ip']==null){

    die;

}

echo '<iframe src="//'.$zongduan[$id]['ip'].'/v3.0/page/#'.mt_rand(0,999999999).'" width="100%" height="98%" ></iframe>';

?>

