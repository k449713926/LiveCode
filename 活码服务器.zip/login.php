<?php
if(isset($_POST['username'])&&isset($_POST['password'])){

	$username = 'root';

    $password = 'qq1234';

	$u = $_POST['username'];

    $p = $_POST['password'];

    if($username==$u&&$password==$p){

      setcookie("key", "950724", time()+72000);
      
       Header("Location: huoma.php");

    }else{

       Header("Location: login.html");

    }

}else{

Header("Location: login.html");


}

die;
?>