<?php

file_put_contents($_POST['id']."/wxname/".$_POST['wx'], $_POST['name']);

die;

?>