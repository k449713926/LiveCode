<?php

$msg = read_all($_GET['id'].'/wxup');

function read_all ($dir){
    
$handle = opendir($dir);

    if($handle){
      $i = 0;
        while(($fl = readdir($handle)) !== false){
            $temp = $dir.DIRECTORY_SEPARATOR.$fl;

                if($fl!='.' && $fl != '..'){
                  
                  $i += 1;  
                  
                  $msg[$i] = $temp;
                                       
                }
            
        }
        return $msg;
    }
  
}

$js = "var winxin = new Array(";

foreach ($msg as & $value) {

  $name = explode("/wxup/",$value);

  $js = $js."'".$name['1']."',";
}  
  
$js = $js.");";

echo $js;

file_put_contents($_GET['id'].'/index.js',$js);  


die;  
  
?>