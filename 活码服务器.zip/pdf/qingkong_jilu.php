<?php

if($_POST['qingkong_jilu'] == 'qingkong_jilu'){

	$file_a = $_POST['id']."/outlog/wxlog";

      file_put_contents($file_a, "");   
	
	$file_b = $_POST['id']."/uplog/wxlog";
	
	  file_put_contents($file_b, "");   
	
}
die;