<?php


$file = $_POST['id']."/urllog/".$_POST['url'];

file_put_contents($file,$_POST['cip']."\r\n", FILE_APPEND);


die;
?>