<?php

$str_list = file_get_contents("list");

$var_list = explode("\r\n",$str_list);

$id = $var_list[$_GET['id']];

$file_path = $id."/luodi"; 

if(file_exists($file_path)){

$str = file_get_contents($file_path);

$var = explode("\n",$str);

if($var[0]==''||$var[0]=="\n"||$var[0]=="\r\n"||$var[0]=="\r"){

	echo '空</br>';

}else if(file_get_contents('http://111.230.153.94/api/UrlWeChat/bbt.php?url='.$var[0]) != 1){
	
	$name = $var[0]."\n";
	
	$res = str_replace($name,'',$str);

    file_put_contents($file_path,$res);

	echo $var[0]."---封";
	
    $file = $id."/f_luodi";

    file_put_contents($file,$name, FILE_APPEND);

}else{

	echo $var[0]."---存活";

}

}


die;

?>