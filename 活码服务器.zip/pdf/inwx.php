<?php

  header("location:inwx_vewi.php?id=".$_GET['id']);

setcookie("adminwx",time(), time()+3600*24);

?>