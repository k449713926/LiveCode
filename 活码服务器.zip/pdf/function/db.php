<?php
class api{
	
	static function opd($take,$sql,$id){

	if($take=='insert'){
		//新增
	$fz=$sql."\r\n"; 

	$file_fz = fopen($id."/uplog/wxlog","a+");

	fwrite($file_fz,$fz);

	fclose($file_fz);

	}



		if($take=='delete'){

		//删除

		$content = substr($sql, 3);

		$fz=$content."\r\n"; 

		$file_fz = fopen($id."/outlog/wxlog","a+");



		fwrite($file_fz,$fz);

		fclose($file_fz);
		
		//var_dump($file_fz);
		}
	}
}
?>