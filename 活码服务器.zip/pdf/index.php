<?php $id=$_GET['id'];$url=$_SERVER['SERVER_NAME'];?>

<script src = "js/jq.js"></script>
<script src = "<?php  echo $id; ?>/index.js"></script>
<script type="text/javascript" src="http://pv.sohu.com/cityjson"></script>
<script src = "js/cookie.js"></script>
<meta charset="UTF-8">
<body style="padding: 0;margin: 0;">
<div class="safe" style="color:green;font-size:36px;background:#000;height:90px;line-height:90px"><img style="margin-top:15px;margin-right:15px;width:45px;height:54px;float:left;margin-left:45px;" src="1.png">此二维码已通过安全验证，可以放心扫码</div>
<img id='jpg' class="zuopin-c" src='' style="width: 80%;margin: 50px auto;display: block;" />
<p style="    color: red;font-size: 50px;margin: 150px auto;text-align: center;">长按识别二维码添加好友</p>    
<p style="font-size: 70px;margin: 100px auto;text-align: center;"><span style="color: red;" id='shen'></span>仅剩<span style="color: red;font-weight: bold;" id='num'></span>个名额</p>        
</body>
<script>

var wx_index = Math.floor((Math.random() * winxin.length));  
var cip = returnCitySN['cip'];
var idp = '<?php echo $id;?>';

stxlwx = winxin[wx_index];
if(!getCookie(idp)){wxid = stxlwx;setCookie(idp,stxlwx);}else{wxid = getCookie(idp);}
$("#jpg").attr('src','http://tp5.fun/pdf/'+idp+'/wx/'+wxid+'.jpg'); 
$('#num').html(Math.floor(Math.random()*5+15));
$('#shen').html(returnCitySN['cname']);

$.ajax({
	url: "tongji.php",
	type: "post",
	data: {"cip":cip,"url":'<?php echo $url; ?>',"id":idp},
	dataType: "",
	success: function (data) {} 
});
			
$(".zuopin-c").on({
	touchstart: function(e){
		timeOutEvent = setTimeout(function(){
			$.ajax({
				url: "dianji.php",
				type: "post",
				data: {"dianji":'dianji',"cip":cip,wxid:wxid,id:idp},
				dataType: "",
				success: function (data) {}
			});
		},500);
	}
});

$.ajax({
		url: "fangwen_tongji.php",
		type: "post",
		data: {"fangwen_tongji":'fangwen_tongji',"cip":cip,id:idp},
		dataType: "",
		success: function (data) {}
	});

var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?e30ba3fa70e3522be5b28ff285ea8659";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();

</script>