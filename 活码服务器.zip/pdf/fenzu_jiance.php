<?php

echo 'star</br>';

$str = file_get_contents("list");

$var = explode("\r\n",$str);

$list = array_filter($var);
	
	foreach ($list as $key => $value) {
		
		$file = $value.'/url';
		
		if(file_exists($file)){

            $st = file_get_contents($file);

			$v = explode("\n",$st);

			file_put_contents($value."/f_list",'');

			foreach ($v as $ke => $valu) {

				if($valu==''||$valu=="\n"||$valu=="\r\n"||$valu=="\r"){

					echo '空</br>';

				}else if(file_get_contents('http://111.230.153.94/api/UrlWeChat/bbt.php?url='.$valu) != 1){
					
					file_put_contents($value."/f_list",$valu."\r\n", FILE_APPEND);
					
					echo $valu."---封</br>";
					
				}else{

					echo $valu."---成功</br>";


				}
				
				
			}
			
		}
		
	}



die;

?>