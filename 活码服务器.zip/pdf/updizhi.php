<?php
$file = $_POST['id'].'/dizhi';

$fz=$_POST['str'];

file_put_contents($file, $fz);

die;
?>