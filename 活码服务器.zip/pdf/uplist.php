<?php

if($_POST['up']=='up'){

$id = $_POST['id'];

$wx =  $_POST['wx'];

file_put_contents($id."/wxup/".$wx, 'up');

}else{

$id = $_POST['id'];

$wx =  $_POST['wx'];

unlink($id."/wxup/".$wx);

}


die;

?>