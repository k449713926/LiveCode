<?php

    

    
    $str = file_get_contents("list");
    
    $name = $_POST['id']."\r\n";
    
    $res = str_replace($name,'',$str);

    file_put_contents("list", $res); 



die;


?>