<?php

include_once "./phpqrcode/phpqrcode.php";

$contents = file_get_contents($_GET['id']."/url");

$list = explode("\n",$contents);

$content = "http://".$list['0']."/index.html?id=".$_GET['id']."#".mt_rand(999,99999999);

QRcode::png($content,false,QR_ECLEVEL_L,6,1,false);

die;

?>