﻿<!DOCTYPE html>

<html>

<head>

	<title>单线管理</title>
	
    <meta charset="utf-8">
	
	<script type="text/javascript" src="js/jq.js"></script>
    
  	<script type="text/javascript" src="laydate/laydate.js"></script>
	
	<script src="js/jszip.js"></script>
	
    <link rel="stylesheet" type="text/css" href="css/index.css?1" />
  
	</head>


<body>

<div class="header">
  <ul>
    <li onclick='$(".rizi").css("display","none");$(".tongji").css("display","none");$(".content_left").css("display","block");$(".content_right").css("display","block");'>首页</li>
    <?php if(isset($_COOKIE['adminwx'])){ ?>  
    <li onclick='$(".rizi").css("display","block");$(".tongji").css("display","none");$(".content_left").css("display","none");$(".content_right").css("display","none");stop();'>日志</li>
	<li onclick='$(".tongji").css("display","block");$(".rizi").css("display","none");$(".content_left").css("display","none");$(".content_right").css("display","none");stop();'>统计</li>
<?php } ?>  
  </ul> 
  
  
</div>

<div class="content_left">

<p><span id = "end_time">500</span>  秒后刷新</p>

<p id = "end_id"><?php echo $num ?></p>

<p id = "now_time">2019/02/25 18:00:23</p>

<p>在线二维码数量</p>

<p onclick = 'stop();'>暂停刷新</p>

<p style="margin-top: 20px;text-align: center;font-size: 20px;color: #5d5d61;font-family: Arial;">入口二维码</p>

<p><img src="obtain.php?id=<?php echo $_GET['id'];?>"/></p>

<p style="margin-top: 20px;text-align: center;font-size: 20px;font-family: Arial;" onclick="$('#login_hidebg').show();$('#tijiao').show();">
	<button style = "color:#fff;background:red;border-radius:5px;width:140px;height:40px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;">生成二维码入口</button>
</p>

<p style="margin-top: 20px;text-align: center;font-size: 20px;font-family: Arial;" onclick="$('#login_hidebg').show();$('#diquxianzhi').show();">
	<button style = "color:#fff;background:#1890ff;border-radius:5px;width:140px;height:40px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;">地区限制</button>
</p>

</div>

<div class="content_right">

<h1>上传文件</h1>  <bottom onclick = "up()">启用</bottom>
  <div class="cb"></div>
<br/>
<?php if(isset($_COOKIE['adminwx'])){ ?>
<form method="post" action="" enctype="multipart/form-data">
    上传文件：<input type="file" name="photo[]" size="20" multiple>
    <input type="submit" value="提交">（最多一次只能上传20张,文件格式仅jpg）
</form>
<?php }?>
  <br>
  
  <ul  class = 'wxtp'>
<?php 

  if($msg){
foreach ($msg as & $value) {
  
   $name  = str_replace($_GET['id']."/wx/","",$value);
   $name  = str_replace(".jpg","",$name);
   $name  = str_replace(".png","",$name);
   $name  = str_replace(".PNG","",$name);
   $name  = str_replace(".JPG","",$name);
   echo '<li><img class="'.$name.'" onclick="img_c(\''.$name.'\',\''.$value.'\')" src="'.$value.'"><p >微信号：<span style="overflow-x: hidden;" class="suoyou_wx">'.$name.'</span></p><p onclick = "xg(\''.$name.'\');">备&ensp;&ensp;注：<input class="beizhu_'.$name.'" onblur="inp_xiugai(\''.$name.'\')" readonly="readonly" type="text" value="无" style="width: 100px;border: none;"></p><p>操&ensp;&ensp;作：<button style = "color:#fff;background:red;border-radius:5px;width:40px;height:25px;display:inline-block;line-height:25px;border: 1px solid #d9d9d9;"><a style="color: #fff;text-decoration: none;" href = "index.php?id='.$_GET['id'].'&killimg='.$value.'">删除</a></button>&ensp;&ensp;&ensp;&ensp;<button style = "color:#fff;background:#1890ff;border-radius:5px;width:40px;height:25px;display:inline-block;line-height:25px;border: 1px solid #d9d9d9;"><span style="color: #fff;" class="xianshi_'.$name.'" href = "" onclick="xianshi_cz(\''.$name.'\')">隐藏</span></button></p></li>';
}  
  }
?>
  </ul>
</div>

<div class="cb"></div>
<?php if(isset($_COOKIE['adminwx'])){ ?>
  <div class = "rizi">
    <h2>操作日志</h2>
    <input type="text" id="test16"><button onclick = "check_log()">立即查询</button><button onclick = "qingkong_jilu()" style="margin-left: 165px;">一键清空记录</button></br>
	
    <ul class = 'up_msg'>
    </ul>
    <ul class = 'out_msg'>
    </ul>
  </div>
<?php } ?>


<div class = "tongji" style="display:none;float: left;width: 40%;margin-left: 5%;">
    <h2 style="text-align: center;margin: 20px;">落地域名统计<button style = "color:#fff;background:#1890ff;border-radius:5px;width:80px;height:40px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;margin-left: 200px;" onclick="qingkong_luodi();">清空</button>  </h2>
    <ul class = 'tongji_list'>
		<table style="width: 90%;margin: 0 auto;">
			<tbody>
				<tr class="ordertr">
					<td>
					  域名
					</td>
					<td>
					  次数
					</td>
				</tr>
				<?php foreach($array_luodi as $key=>$val) {?>
				<tr class="ordertr">
					<td>
					  <?php echo $val[0]?>
					</td>
					<td>
					  <?php echo $val[1]?>次
					</td>
				</tr>
				<?php }?>
			</tbody>
		</table>
    </ul>  
</div>

<div class = "tongji" style="display:none;float: left;width: 40%;margin-left: 5%;">
    <h2 style="text-align: center;margin: 20px;">入口域名统计<button style = "color:#fff;background:#1890ff;border-radius:5px;width:80px;height:40px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;margin-left: 200px;" onclick="qingkong_rukou();">清空</button></h2>
    <ul class = 'tongji_list'>
		<table style="width: 90%;margin: 0 auto;">
			<tbody>
				<tr class="ordertr">
					<td>
					  域名
					</td>
					<td>
					  次数
					</td>
				</tr>
				<?php foreach($array_rukou as $key=>$val) {?>
				<tr class="ordertr">
					<td>
					  <?php echo $val[0]?>
					</td>
					<td>
					  <?php echo $val[1]?>次
					</td>
				</tr>
				<?php }?>
			</tbody>
		</table>
    </ul>  
</div>

<br style="clear: both;" />

<div class = "tongji" style="display:none;float: left;width: 40%;margin-left: 5%;">
    <h2 style="text-align: center;margin: 20px;">二维码点击统计<button style = "color:#fff;background:#1890ff;border-radius:5px;width:80px;height:40px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;margin-left: 200px;" onclick="img_qingkong();">清空</button></h2>
    <ul class = 'tongji_list'>
		<table style="width: 90%;margin: 0 auto;">
			<tbody class="img_tongji_list">
				<tr class="ordertr">
					<td>
					  图片名称
					</td>
					<td>
					  次数
					</td>
				</tr>
				
			</tbody>
		</table>
    </ul>  
</div>

<div class = "tongji" style="display:none;float: left;width: 40%;margin-left: 5%;">
    <h2 style="text-align: center;margin: 20px;">超过3秒访问统计 <button style = "color:#fff;background:#1890ff;border-radius:5px;width:80px;height:40px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;margin-left: 200px;" onclick="qingkong_fangwen();">清空</button> </h2>
    <ul class = 'tongji_list'>
		<table style="width: 90%;margin: 0 auto;">
			<tbody>
				<tr class="ordertr">
					<td>
					  项目
					</td>
					<td id="saoma_dakai">
					  次数
					</td>
				</tr>
				<tr class="ordertr">
					<td>
					  扫码次数
					</td>
					<td id="saoma_cishu">
					  0
					</td>
				</tr>
				<tr class="ordertr">
					<td>
					  打开次数
					</td>
					<td id="dakai_cishu">
					  0
					</td>
				</tr>
			</tbody>
		</table>
    </ul>  
</div>

<br style="clear: both;" />

<button style = "color:#fff;background:#1890ee;border-radius:5px;width:140px;height:40px;display:block;line-height:30px;border: 1px solid #d9d9d9;margin: 0 auto;" onclick="qingkong_fangwen();img_qingkong();qingkong_rukou();qingkong_luodi();">全部清空</button> 





<div class="cb">
	<!-- 获取文件夹内所有文件-->
	<?php

	$img_list = read_all_dir($_GET['id'].'/img_log');
	$img = $img_list["file"];

	?>
	<div id="img_name" style="display:none;">
	<?php foreach($img as $key=>$val) {?>
		<span class="img_class"><?php echo $img[$key]?></span>
	<?php }?>
	</div>
</div>  

<div id="login_hidebg" style = 'position:fixed;left:0px;top:0px;background-color:#000;width:100%; filter:alpha(opacity=60);  opacity:0.6; display:none; z-Index:2;height:100%'></div>

<div id="login_hid" onclick='$("#img_xs").hide();$("#login_hid").hide();$("#img_xs").html("");' style = 'position:fixed;left:0px;top:0px;background-color:#000;width:100%; filter:alpha(opacity=60);  opacity:0.6; display:none; z-Index:2;height:100%'></div>

<div id="tijiao" style = 'display:none;background: rgb(255, 255, 255);width: 600px;height: 450px;z-index: 3;position: fixed;top: 200px;left: 50%;margin-left: -250px;text-align: center;border-radius: 5px;'>
	<div id="jiazai_shengyu" style="margin: 20px 0;">
		<textarea id="textarea" wrap="hard" cols="90" rows="15" style="width: 400px;height: 360px;">每行一个域名</textarea>
	</div>
	<button style = "color:#fff;background:red;border-radius:5px;width:100px;height:30px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;" onclick = '$("#tijiao").hide();$("#login_hidebg").hide();location.reload();'>关闭</button>
	<button type="button" class="ant-btn ant-btn-primary" style="color:#fff;background:#1890ff;border-radius:5px;width:100px;height:30px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;margin-left: 130px;"  onclick="rukou()"><span>提交</span></button>
	<div id="img" style="display:none;">
	
	</div>
</div>
<div id="diquxianzhi" style = 'display:none;background: rgb(255, 255, 255);width: 600px;height: 450px;z-index: 3;position: fixed;top: 200px;left: 50%;margin-left: -250px;text-align: center;border-radius: 5px;'>
	<div id="jiazai_shengyu" style="margin: 20px 0;">
		<textarea id="textarea_diqu" wrap="hard" cols="90" rows="15" style="width: 400px;height: 360px;">多个地区逗号隔开,</textarea>
	</div>
	<button style = "color:#fff;background:red;border-radius:5px;width:100px;height:30px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;" onclick = '$("#diquxianzhi").hide();$("#login_hidebg").hide();location.reload();'>关闭</button>
	<button type="button" class="ant-btn ant-btn-primary" style="color:#fff;background:#1890ff;border-radius:5px;width:100px;height:30px;display:inline-block;line-height:30px;border: 1px solid #d9d9d9;margin-left: 130px;"  onclick="diqu()"><span>提交</span></button>
</div>
<div id="img_xs" style = 'display:none;background: rgb(255, 255, 255);width: 600px;height: 450px;z-index: 3;position: fixed;top: 200px;left: 50%;margin-left: -250px;text-align: center;border-radius: 5px;'>
	
</div>
</body>

<script>

$('#now_time').html(now());

var key = GetQueryString('key');
  
var reciprocal = setInterval(function(){end_time()},1000);
  
function stop(){
		
	clearInterval(reciprocal);
	
	alert('操作中，停止页面刷新');
	
}	
   
function GetQueryString(name)
{
	
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
	 
     var r = window.location.search.substr(1).match(reg);
	 
     if(r!=null)return  unescape(r[2]); return null;
	 
}


function end_time(){
	
  var end_time	= $('#end_time').html()-1;
  
  $('#end_time').html(end_time);
  
  if(end_time==0){
	  
	  location.reload();
	  
  }
	
}

function now(){
	
var myDate = new Date();

var year=myDate.getFullYear();

var month=myDate.getMonth()+1;

var date=myDate.getDate(); 

var h=myDate.getHours();   
    
var m=myDate.getMinutes();  
 
var s=myDate.getSeconds();  

var now=year+'-'+getNow(month)+"-"+getNow(date)+" "+getNow(h)+':'+getNow(m)+":"+getNow(s);

	return now;
	
}

function getNow(s) {
	
    return s < 10 ? '0' + s: s;
	
}



 function getMyDate(str){  
            var oDate = new Date(str),  
            oYear = oDate.getFullYear(),  
            oMonth = oDate.getMonth()+1,  
            oDay = oDate.getDate(),  
            oHour = oDate.getHours(),  
            oMin = oDate.getMinutes(),  
            oSen = oDate.getSeconds(),  
            oTime = oYear +'-'+ getzf(oMonth) +'-'+ getzf(oDay) +' '+ getzf(oHour) +':'+ getzf(oMin) +':'+getzf(oSen);//最后拼接时间  
            return oTime;  
        }; 
        //补0操作
      function getzf(num){  
          if(parseInt(num) < 10){  
              num = '0'+num;  
          }  
          return num;  
      }

function up(){
   
   alert('正在启用您的计划,请稍等'); 
   
  $.get("now.php?id=<?php echo $_GET['id'];?>", function(result){
   if(result='200'){
   alert('启动成功');      
   }else{
   alert('启动失败');   
   }
  });
   
 }
  
//天空骑士后台模版  
  
 laydate.render({
  elem: '#test16'
  ,type: 'datetime'
  ,range: '到'
  ,format: 'yyyy年M月d日H时m分s秒'
});  
$('#test16').css('width','400px');
  
  
function add0(m){return m<10?'0'+m:m }
  
function format(shijianchuo){
var time = new Date(shijianchuo);
var y = time.getFullYear();
var m = time.getMonth()+1;
var d = time.getDate();
var h = time.getHours();
var mm = time.getMinutes();
var s = time.getSeconds();
return y+'-'+add0(m)+'-'+add0(d)+' '+add0(h)+':'+add0(mm)+':'+add0(s);
}  
  
  
function uplog(start_time,end_time){
  
   $.get("function/uplog.php?id="+<?php echo $_GET['id'];?>+"&start_time="+start_time+"&end_time="+end_time, function(result){ 

	result = JSON.parse(result);
	
	
      if(result==''){
       
            //alert('该时间无数据');
         
     }else if(result){
              
      msg = '<?php echo json_encode($msg) ;?>'  ;
      
      msg_num = '<?php echo count($msg)?>'; 
	  
      msg = JSON.parse(msg);


     msgup = result;
        
     html = "      <li><span>添加记录</span>            <span class = 'upnum'>"+msgup.length+"</span>   个</li>";
       
     chhtml = 0;        
       
     for(var j = 0,len = msgup.length; j < len; j++){
        
     date = format(msgup[j][1]*1000);  
        
     html +="<li>"+date+"    "+msgup[j][0]+"</li>";   
         
     
       
     }
              
     $('.up_msg').html(html);       
       
       
     }else{
       
       alert('服务器无响应');
       
     }
     
   }); 
  
}
  
function outlog(start_time,end_time){
 
   $.get("function/outlog.php?id="+<?php echo $_GET['id'];?>+"&start_time="+start_time+"&end_time="+end_time, function(result){ 
     
    if(result=='null'){
       
            //alert('该时间无数据');
         
     }else if(result){
          
      msgout = JSON.parse(result);
      
      html = "      <li><span>删除记录</span>            <span class = 'outnum'>"+msgout.length+"</span>   个</li>";
      
      for(var j = 0,len = msgout.length; j < len; j++){
        
      var date = format(msgout[j][1]*1000);  
        
      html +="<li>"+date+"    "+msgout[j][0]+"</li>";   
         
      }
              
      $('.out_msg').html(html);
       
     }else{
       
       alert('服务器无响应');
       
     }   
     
   });   
  
}
<?php if(isset($_COOKIE['adminwx'])){ ?>  
uplog(0,0);  
  
outlog(0,0); 
<?php } ?>  
    
 function check_log(){
   
   pull = $('#test16').val();
   
   pull = pull.replace('年','-'); 
   
   pull = pull.replace('年','-'); 
   
   pull = pull.replace('月','-'); 
   
   pull = pull.replace('月','-'); 
   
   pull = pull.replace('日',' '); 
 
   pull = pull.replace('日',' ');   
   
   pull = pull.replace('时',':');   
   
   pull = pull.replace('时',':');     
   
   pull = pull.replace('分',':');     
   
   pull = pull.replace('分',':');  
   
   pull = pull.replace('秒','');  
   
   pull = pull.replace('秒','');     
   
   arr=pull.split(' 到 ');
   
   uplog(arr[0],arr[1]);
   
   outlog(arr[0],arr[1]);   

   
 }
  
function rukou(){

	$(".wxtp").remove();
	
	str = $("#textarea").val();
	
	var snsArr= new Array();
	
    snsArr=str.split(/[(\r\n)\r\n]+/);
	
    snsArr.forEach((item,index)=>{
		
          if(!item){
			  
              snsArr.splice(index,1);
          }
    })
	var array=snsArr;

	if(array[0] == '每行一个域名'){
		
		alert('内容不能为空');
		
	}else{
	
		var data={};
		
		var desiredArr=new Array();
		
		for(var i=0;i<array.length;i++){
			
			data[array[i]]=array[i];
			
		}
		for(var pro in data){
			
		 desiredArr.push(data[pro]);
		 
		}
		
		var tab = desiredArr;
		
		for(var i=0;i<tab.length;i++){
			
			id = tab[i].split(".");
			
			id = id[0];
			
			$("#img").prepend('<img id="'+id+'" src="rukou.php?url='+tab[i]+'&id='+<?php echo $_GET['id']?>+'"/>');

			nub = (tab.length)*300;

			if(i == tab.length-1){
				setTimeout(function () {
						piliang();
				}, nub)
			}
		}
	}
}

function piliang(){
	
	function getBase64Image(img) {
		let canvas = document.createElement("canvas");
		canvas.width = img.width;
		canvas.height = img.height;

		let ctx = canvas.getContext("2d");
		ctx.drawImage(img, 0, 0, img.width, img.height);
		let dataURL = canvas.toDataURL("image/jpeg");
		return dataURL;
	}

	let imgList = [...document.getElementsByTagName('img')]
	imgList.shift()
	console.log(imgList)
	let buffer = imgList.map(getBase64Image)
	console.log('buffer', buffer)

	function saveAs(blob, name) {
		let a = document.createElement('a')
		let url = window.URL.createObjectURL(blob)
		a.href = url
		a.download = name
		a.click()
	}
	async function main() {
		let zip = new JSZip();

		let p = buffer.map(
			x => zip.file(Math.random().toString('36').slice(3) + '.jpeg', x.split(',')[1], {base64: true})
		)

		await Promise.all(p)
		zip.generateAsync({type: "blob"}).then(function (content) {
			var myDate = new Date()
			saveAs(content, "二维码-"+myDate.toLocaleString()+"-"+myDate.getDate()+"-"+myDate.getHours()+"-"+myDate.getMinutes()+".zip");
		});
	}
	
	main();
}

function qingkong_luodi(){
	
  $.ajax({
	  
	url: "del_text.php",
	
	type: "post",
	
	data: {"del":"luodi_del","id":<?php echo $_GET['id'];?>},
	
	dataType: "",
	
	success: function (data) {
		
			alert('清除成功');
			
			location.reload();
			
                }
				
            });
}


function qingkong_fangwen(){
	
  $.ajax({
	  
	url: "del_text.php",
	
	type: "post",
	
	data: {"del":"fangwen_del","id":<?php echo $_GET['id'];?>},
	
	dataType: "",
	
	success: function (data) {
		
			alert('清除成功');
			
			location.reload();
			
                }
				
            });
}



function qingkong_rukou(){
	
  $.ajax({
	  
	url: "del_text.php",
	
	type: "post",
	
	data: {"del":"rukou_del","id":<?php echo $_GET['id'];?>},
	
	dataType: "",
	
	success: function (data) {
		
			alert('清除成功');
			
			location.reload();
			
                }
				
            });
}

function img_qingkong(){
	
  $.ajax({
	  
	url: "del_text.php",
	
	type: "post",
	
	data: {"img_del":"img_del","id":<?php echo $_GET['id'];?>},
	
	dataType: "",
	
	success: function (data) {
		
			alert('清除成功');
			
			location.reload();
			
                }
				
            });
}

function qingkong_jilu(){
	
  $.ajax({
	  
	url: "qingkong_jilu.php",
	
	type: "post",
	
	data: {"qingkong_jilu":"qingkong_jilu","id":<?php echo $_GET['id'];?>},
	
	dataType: "",
	
	success: function (data) {
		
			alert('清除成功');
			
			location.reload();
			
                }
				
            });
}

function diqu(){
	
	diqu_list = $("#textarea_diqu").val();
	
	str = diqu_list.replace(/，/, ",");
	
	if(str == '多个地区逗号隔开,'){
		
		alert('内容不能为空');
		
	}else{
		
		$.ajax({
			
			url: "updizhi.php",
			
			type: "post",
			
			data: {"str":str,"id":<?php echo $_GET['id'];?>},
			
			dataType: "",
			
			success: function (data) {
				
					alert('提交成功');
					
					location.reload();
					
					
			}
		});
		
		
	}
}
function list_dizhi(){
	
	url = '<?php echo $_GET['id'];?>/dizhi';

	$.get(url + '?' + Math.ceil(Math.random() * 10000000), function(data) {
		
		$('#textarea_diqu').html(data);
		
	})
}

list_dizhi();

function saoma(){
	
	url = '<?php echo $_GET['id'];?>/dianjitongji';

	$.get(url + '?' + Math.ceil(Math.random() * 10000000), function(data) {
		str=data; //这是一字符串
		var snsArr= new Array(); //定义一数组
		snsArr=str.split(/[(\r\n)\r\n]+/);
		snsArr.forEach((item,index)=>{
			  if(!item){
				  snsArr.splice(index,1);//删除空项
			  }
		})
		var array=snsArr;  
		var data={};      
		var desiredArr=new Array();    
		for(var i=0;i<array.length;i++){    
			data[array[i]]=array[i];    
		}   
		for(var pro in data){    
		 desiredArr.push(data[pro]);  
		}
		var saoma_tab = desiredArr;
		$('#saoma_cishu').html(saoma_tab.length);

		
	});
}

saoma();

function fangwen(){
	
	url = '<?php echo $_GET['id'];?>/fangwen_tongji';

	$.get(url + '?' + Math.ceil(Math.random() * 10000000), function(data) {
		str=data; //这是一字符串
		var snsArr= new Array(); //定义一数组
		snsArr=str.split(/[(\r\n)\r\n]+/);
		snsArr.forEach((item,index)=>{
			  if(!item){
				  snsArr.splice(index,1);//删除空项
			  }
		})
		var array=snsArr;  
		var data={};      
		var desiredArr=new Array();    
		for(var i=0;i<array.length;i++){    
			data[array[i]]=array[i];    
		}   
		for(var pro in data){    
		 desiredArr.push(data[pro]);  
		}
		var dakai_tab = desiredArr;
		$('#dakai_cishu').html(dakai_tab.length);

        setTimeout("saoma_dakai()","120");
	});
}

fangwen();
  

function saoma_dakai(){

	     attribute1 = $('#saoma_cishu').html();
         attribute2 = $('#dakai_cishu').html();
        //运算

         checkResult = Number(attribute1)/Number(attribute2)*100;
        //四舍五入 保留两位小数 打印到控制台
        $('#saoma_dakai').html(checkResult.toFixed(2)+'%');
}

function img_tongji(){
	var btns = new Array();
    $('.img_class').each(function(key,value){
		btns[key] = $(this).html();
	});
	for(var i=0;i<btns.length;i++){
		urlname = btns[i].split('/');
		$('.img_tongji_list').append('<tr class="ordertr"><td>'+urlname[2]+'</td><td class="img_tongji_'+i+'"></td></tr>');
		geturl(btns[i],i);
		//url = btns[i];
	}
}
function geturl(url,id){
	$.get(url + '?' + Math.ceil(Math.random() * 10000000), function(data) {
			
			str=data; //这是一字符串
			var snsArr= new Array(); //定义一数组
			snsArr=str.split(/[(\r\n)\r\n]+/);
			snsArr.forEach((item,index)=>{
				  if(!item){
					  snsArr.splice(index,1);//删除空项
				  }
			})
			var array=snsArr;  
			var data={};      
			var desiredArr=new Array();    
			for(var i=0;i<array.length;i++){    
				data[array[i]]=array[i];    
			}   
			for(var pro in data){    
			 desiredArr.push(data[pro]);  
			}
			
			console.log(id,986454);
			$('.img_tongji_'+id+'').html(desiredArr.length);
			
			
			
		})
}
img_tongji();
function img_c(id,src){
	$('#img_xs').show();
	$('#login_hid').show();
	$('#img_xs').html('<img style="width: 300px;height: 300px;margin-top: 65px;" src="'+src+'"/>');
}
function beizhu_chaxun(){
	var tags = [];
	$(".suoyou_wx").each(function(i,e){
		tags[i]= $(this).context.innerText;
	});
	$.each(tags, function (index, id) {
		$.get('<?php echo $_GET['id'];?>/wxname/'+id+'?' + Math.ceil(Math.random() * 10000000), function(data) {
			$('.beizhu_'+id).val(data);
			//console.log(data,9999);
		})
		$.get('<?php echo $_GET['id'];?>/wxup/'+id+'?' + Math.ceil(Math.random() * 10000000), function(data) {
			$('.xianshi_'+id).html('显示');
			//console.log(data,9999);
		})
	})
	
}
beizhu_chaxun();
function xg(id){
	$('.beizhu_'+id).removeAttr('readonly');
}
function inp_xiugai(id){
	val = $('.beizhu_'+id).val();
	if(val != '无'){
		$.ajax({
			url: "beizhu.php",
			type: "post",
			data: {"name":val,"wx":id,"id":<?php echo $_GET['id'];?>},
			dataType: "",
			success: function (data) {
					//alert('修改成功');
					//location.reload();
			}
		});
	}
}
function xianshi_cz(id){
	val = $('.xianshi_'+id).text();
	if(val == '显示'){
		up = 'yc';
	}else{
		up = 'up';
	}
	$.ajax({
		url: "uplist.php",
		type: "post",
		data: {"up":up,"wx":id,"id":<?php echo $_GET['id'];?>},
		dataType: "",
		success: function (data) {
					location.reload();
		}
	});
}
</script>

</html>
