<?php 

include 'function/db.php';


if(isset($_GET['killimg'])){
  
  unlink ($_GET['killimg']);
	
  include 'now.php?id='.$_GET['id'];

  $wx  =  str_replace('wx/','',$_GET['killimg']);
  
  $wx  =  str_replace('.jpg','',$wx);
 
  $wx  =  str_replace('.png','',$wx);    
  
  $wx  =  str_replace($_GET['id'].'/','',$wx); 

    unlink ($_GET['id'].'/wxup/'.$wx);
  
  $sql = $_GET['killimg'].",".time();
  
  api::opd('delete',$sql,$_GET['id']);

  header("location:inwx_vewi.php?id=".$_GET['id']);
  
  die;
  
}




if($_FILES) {

    //遍历所有照片的类型，判断上传的类型是否是常用的照片类型
    foreach($_FILES['photo']['type'] as $key=>$value) {
      
        switch ($value) {
            
            case 'image/jpeg': $ext = 'jpg';
            
                break;
            
            case 'image/jpeg': $ext = 'jpg';

            default:
            
                $ext = '';
            
                break;
            
        }
      
        

        if($ext) {

            $name = $_GET['id'].'/wx/'.$_FILES['photo']['name'][$key];

          if($_FILES['photo']['size'][$key]<'1048576'){
            
            move_uploaded_file($_FILES['photo']['tmp_name'][$key], $name);

              $wx  =  str_replace('.jpg','',$_FILES['photo']['name'][$key]);
 
              $wx  =  str_replace('.png','',$wx);  
			  
			  $sql = $_FILES['photo']['name'][$key].",".time();
			
              api::opd('insert',$sql,$_GET['id']);	

           }
           
            header("location:inwx_vewi.php?id=".$_GET['id']);
       
        }
    }
}







$num = ShuLiang($_GET['id']."/wx/*");//用这个方法查一下该路径下所有的文件数量;

$msg = read_all_check($_GET['id'].'/wx');






function read_all_check ($dir){
    
    $handle = opendir($dir);

    if($handle){
      
      $i = 0;
      
        while(($fl = readdir($handle)) !== false){
          
            $temp = $dir.DIRECTORY_SEPARATOR.$fl;

                if($fl!='.' && $fl != '..'){
                  
                  $i += 1;  
                  
                  $msg[$i] = $temp;
                                       
                }
            
        }
      
        return $msg;
      
    }
  
}


  function read_all_dir ( $dir ){
    $result = array();
    $handle = opendir($dir);//读资源
    if ($handle){
      while (($file = readdir($handle)) !== false ){
        if ($file != '.' && $file != '..'){
          $cur_path = $dir . DIRECTORY_SEPARATOR . $file;
          if (is_dir($cur_path )){//判断是否为目录，递归读取文件
            $result['dir'][$cur_path] = read_all_dir($cur_path );
          }else{
            $result['file'][] = $cur_path;
          }
        }
      }
      closedir($handle);
    }
    return $result;
  }

function ShuLiang($url)//造一个方法，给一个参数
{
    $sl=0;//造一个变量，让他默认值为0;
    $arr = glob($url);//把该路径下所有的文件存到一个数组里面;
    foreach ($arr as $v)//循环便利一下，吧数组$arr赋给$v;
    {
        if(is_file($v))//先用个if判断一下这个文件夹下的文件是不是文件，有可能是文件夹;
        {
            $sl++;//如果是文件，数量加一;
        }
        else
        {
            $sl+=ShuLiang($v."/*");//如果是文件夹，那么再调用函数本身获取此文件夹下文件的数量，这种方法称为递归;
        }
    }
    return $sl;//当这个方法走完后，返回一个值$sl,这个值就是该路径下所有的文件数量;
}




$luodi_log = scandir($_GET['id'].'/urllog');


$luodi_n = 0;

$array_luodi = [];

for($i=2;$i<=20;$i++){

  if($luodi_log[$i]!=null){

  $urllog_num = file_get_contents($_GET['id']."/urllog/".$luodi_log[$i]);

  $urllog_num = explode("\r\n",$urllog_num);

  $urllog_num = array_filter($urllog_num);

  $urllog_num = count($urllog_num);

  $array_luodi[$luodi_n][0] = $luodi_log[$i];

  $array_luodi[$luodi_n][1] = $urllog_num;
   
   $luodi_n += 1;

  }
}



$rukou_log = scandir($_GET['id'].'/rukoulog');

$rukou_n = 0;

$array_rukou = [];

for($i=2;$i<=20;$i++){

  if($rukou_log[$i]!=null){

  $urllog_num = file_get_contents($_GET['id']."/rukoulog/".$rukou_log[$i]);

  $urllog_num = explode("\r\n",$urllog_num);

  $urllog_num = array_filter($urllog_num);

  $urllog_num = count($urllog_num);

  $array_rukou[$rukou_n][0] = $rukou_log[$i];

  $array_rukou[$rukou_n][1] = $urllog_num;
   
   $rukou_n += 1;

  }
}

include 'vewi.php';
