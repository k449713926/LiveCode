<?php
$file = $_POST['id']."/fangwen_tongji";

$time = date("Y-m-d H:i:s");

file_put_contents($file,$_POST['cip'].'----'.$time."\r\n", FILE_APPEND);

die;
?>