<?php

if($_POST['del'] == 'fangwen_del'){

file_put_contents($_POST['id'].'/fangwen_tongji','');

}else if($_POST['del'] == 'luodi_del'){

	$path = $_POST['id']."/urllog";

   	deleteDir($path);
	
   $dir = iconv("UTF-8", "GBK", $_POST['id']."/urllog");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}
	
}else if($_POST['del'] == 'rukou_del'){

	$path = $_POST['id']."/rukoulog";

	deleteDir($path);
	
   $dir = iconv("UTF-8", "GBK", $_POST['id']."/rukoulog");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}
	
}else if($_POST['img_del'] == 'img_del'){

	$path = $_POST['id']."/img_log";

	deleteDir($path);
	
   $dir = iconv("UTF-8", "GBK", $_POST['id']."/img_log");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}
	
}

	





	function deleteDir($dir)
	{
		if (!$handle = @opendir($dir)) {
			return false;
		}
		while (false !== ($file = readdir($handle))) {
			if ($file !== "." && $file !== "..") {
				$file = $dir . '/' . $file;
				if (is_dir($file)) {
					deleteDir($file);
				} else {
					@unlink($file);
				}
			}

		}
		@rmdir($dir);
	}



die;

?>