<?php

$id = $_POST['id'];

     $dir = iconv("UTF-8", "GBK", $id."/rukoulog");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}

     $file = $id."/rukoulog/".$_SERVER['SERVER_NAME'];

file_put_contents($file,$_SERVER["REMOTE_ADDR"]."\r\n", FILE_APPEND);


die;
?>